import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
df_iris =pd.read_csv('C:/Users/Zhansaya/projects/zizi/static/result.csv')
iris_train, iris_test = train_test_split(df_iris, test_size = 0.3, random_state = 10)

#Create a unique list of classes
unique_targets = iris_train["Специальность(Код)"].unique().tolist()
models = {}

#Build Models
for elem in unique_targets:
    lr = LogisticRegression()
    lr.fit(iris_train[["Первый предмет(ID)", "Второй предмет(ID)", "Направление(ID)" ]], iris_train["Специальность(Код)"] == elem)
    models[elem] = lr

#Create an empty data frame
testing_probs = pd.DataFrame(columns=unique_targets)

#Calculate the probabilities for the same data using the models built
for elem in unique_targets:
    lr = models[elem]
    ls = lr.predict_proba(iris_test[["Первый предмет(ID)", "Второй предмет(ID)", "Направление(ID)"]])
    testing_probs[elem] = ls[:,1]

#pick the class with high
l = [4,10,10]
a = np.array([l])
testing_prob = pd.DataFrame(columns=unique_targets)
testing_probl = pd.DataFrame(columns=unique_targets)

for elem in unique_targets:
    lr = models[elem]
    ls = lr.predict_proba(a)
    testing_prob[elem] = ls[:,1]
    testing_probl[elem] = ls[:,0]

df_irist =pd.read_csv('C:/Users/Zhansaya/projects/zizi/static/prof.csv')
profs =[]
for i in range(len(df_irist['Specialty'])):
    if(df_irist['Specialty'][i]==testing_prob.idxmax(axis = 1)[0]):
        profs.append(df_irist['Profession_eng'][i])
print(profs)