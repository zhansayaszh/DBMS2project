from django.urls import path

from . import views

urlpatterns =[
    path('',views.form1, name='form1'), 
    path('add', views.add, name='add'),
    path('speciality', views.speciality, name='speciality')
    ]