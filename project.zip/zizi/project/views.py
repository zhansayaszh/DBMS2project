from django.shortcuts import render
from django.http import HttpResponse
from .models import Student
import cx_Oracle
from project.connectDb import ConnectDb
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt

# Create your views here.
def form1(request):
    return render(request,'form1.html')

def add(request):
    student= Student()
    student.name= request.POST['student_name']
    student.surname= request.POST['student_surname']
    student.age= request.POST['student_age']
    student.gender= request.POST['gender']
    student.city_name= request.POST['city_name']
    student.subject1= request.POST['subject1']
    student.subject2= request.POST['subject2']
    student.points= int(request.POST['points'])
    student.grants= request.POST['grants']
    student.dorm= request.POST['dorm']
    student.sphere= request.POST['sphere']

    df_iris =pd.read_csv('C:/Users/Zhansaya/projects/zizi/static/result.csv')
    iris_train, iris_test = train_test_split(df_iris, test_size = 0.3, random_state = 10)

    #Create a unique list of classes
    unique_targets = iris_train["Специальность(Код)"].unique().tolist()
    models = {}

    #Build Models
    for elem in unique_targets:
        lr = LogisticRegression()
        lr.fit(iris_train[["Первый предмет(ID)", "Второй предмет(ID)", "Направление(ID)" ]], iris_train["Специальность(Код)"] == elem)
        models[elem] = lr

    #Create an empty data frame
    testing_probs = pd.DataFrame(columns=unique_targets)

    #Calculate the probabilities for the same data using the models built
    for elem in unique_targets:
        lr = models[elem]
        ls = lr.predict_proba(iris_test[["Первый предмет(ID)", "Второй предмет(ID)", "Направление(ID)"]])
        testing_probs[elem] = ls[:,1]

    #pick the class with high
    l = [4,10,1]
    a = np.array([l])
    testing_prob = pd.DataFrame(columns=unique_targets)
    testing_probl = pd.DataFrame(columns=unique_targets)

    for elem in unique_targets:
        lr = models[elem]
        ls = lr.predict_proba(a)
        testing_prob[elem] = ls[:,1]
        testing_probl[elem] = ls[:,0]

    df_irist =pd.read_csv('C:/Users/Zhansaya/projects/zizi/static/prof.csv')
    profs =[]
    for i in range(len(df_irist['Specialty'])):
        if(df_irist['Specialty'][i]==testing_prob.idxmax(axis = 1)[0]):
            profs.append(df_irist['Profession_eng'][i])

    # frame = pd.DataFrame(profs)
    # frame.to_csv('profs.csv')
    conn= cx_Oracle.connect('SYSTEM/zhanna2011@localhost/xe')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO STUDENTS VALUES (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11)', 
     (student.name,student.surname,student.age,student.gender,student.city_name, student.subject1,student.subject2,student.points,student.grants,student.dorm,student.sphere))
    conn.commit()
    cursor.close()
    return render(request,'form2.html', {'result':profs,'dorm':student.dorm, 'city':student.city_name})

def speciality(request):
    prof = request.POST['prof'] 
    dorm = request.POST['new_dorm'] 
    city = request.POST['city'] 
    
    profess =pd.read_csv('C:/Users/Zhansaya/projects/zizi/static/prof.csv')
    full =pd.read_csv('C:/Users/Zhansaya/projects/zizi/static/result4.csv')
    #full['Город(ID)'][j] == 3 and full['Общежитие'][j] == 1
    all_data = []
    for i in range(len(profess)):
        if (profess['Profession_eng'][i]==prof):
            for j in range(len(full)):
                if profess['Specialty'][i] == full['Специальность(Код)'][j] and full['Город(ID)'][j] == 3 and full['Общежитие'][j] == 1:
                    all_data.append({'university':full['Название(RU)_y'][j],'description':full['Описание(RU)_x'][j],'dormitory':full['Общежитие'][j]})
        
    return render(request,'form3.html', {'result': all_data, 'Speciality':prof, 'City':city, 'Dorm': dorm})

    