from django.db import models

# Create your models here.

class Student(models.Model):
    name= models.CharField(max_length=256)
    surname= models.CharField(max_length=256)
    age= models.CharField(max_length=256, default='01/01/2000')
    gender= models.CharField(max_length=256)
    city_name= models.CharField(max_length=256)
    subject1= models.CharField(max_length=256)
    subject2= models.CharField(max_length=256)
    points= models.IntegerField
    grants= models.CharField(max_length=256)
    dorm= models.CharField(max_length=256)
    sphere= models.CharField(max_length=256)



        