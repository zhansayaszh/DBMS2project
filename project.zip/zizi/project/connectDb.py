import cx_Oracle
class ConnectDb():
    connection = None
    
    def connect_db(self):
        self.connection = cx_Oracle.connect('SYSTEM/zhanna2011@localhost/xe')

    def update_or_insert_db(self, sql, fields):
        cursor = self.connection.cursor()
        cursor.execute(sql, fields)
        self.connection.commit()
        cursor.close()

    def select_all_db(self, sql, fields={}):
        full_list = []
        try:
            cursor = self.connection.cursor()
            cursor.execute(sql, fields)
            cursor.arraysize = 256
            for row in cursor:
                full_list.append(row)
            cursor.close()
            return full_list
        except Exception as e:
            print(str(e))